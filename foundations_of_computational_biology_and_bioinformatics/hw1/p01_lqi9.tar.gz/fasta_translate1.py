#!/usr/bin/env python
import sys
a = sys.stdin					#file name	
c = []				 
dic = {}		
des = a.readline().strip().lstrip('>')		#first line get the descriptor	
line = a.readline()    				 #second line
while line != "":
	d = line.rstrip('\n')
	c.append(d)	
	line = a.readline()
a.close()
c = ''.join(c)				 #delete the ','
dic[des]=c
print(dic)		#print the dictionary
