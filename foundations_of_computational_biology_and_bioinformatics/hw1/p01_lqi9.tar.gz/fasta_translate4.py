#!/usr/bin/env python
import sys
codon = open('codon_table_hard.txt','r')
pt={}
line = codon.readline()
b=[]
#get codons
while line != "":
	a = line.rstrip().split('\t')
	if ',' in a[2]:				
		b = a[2].split(',')		
		for i in b:
			pt[i] = a[1]
#get the amino acids which have mutiple codons
	else:		
		pt[a[2]] = a[1]
	line = codon.readline()
codon.close()
#get mRNA
seq={}
line = sys.stdin.readline()
while line != '':
	if line.startswith('>'):
		name = line.strip().rstrip('\n')
		seq[name]=''
	else:
		seq[name] += line.strip().rstrip('\n')
	line = sys.stdin.readline()
sys.stdin.close()
#translate
for i in seq:
	seq[i] = seq[i][:int(len(seq[i])//3)*3]
	protein = ''
	for n in range(len(seq[i])//3):
		if seq[i][3*n:3*n+3] in pt:
			protein += pt[seq[i][3*n:3*n+3]]
		else:
			sys.stderr.write('{} is not in codon table\n'\
.format(seq[i][3*n:3*n+3]))
	sys.stdout.write('{}\n{}\n'.format(i,protein))	
