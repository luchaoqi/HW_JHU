#!/usr/bin/env python
"""save the mRNA sequnce to a dictionary"""
import sys
seq={}
#get mRNA
line = sys.stdin.readline()
while line != '':
	if line.startswith('>'):
		name = line.strip()
		seq[name]=''
	else:
		seq[name] += line.replace('\n','').strip()
	line = sys.stdin.readline()
sys.stdin.close()
#get codons
codon = open('codon_table.txt','r')
pt={}
line = codon.readline()
while line != "":
	a = line.rstrip().split('\t')
	pt[a[0]]=a[1]
	line = codon.readline()
codon.close()
for i in seq:
	seq[i] = seq[i][:int(len(seq[i])//3)*3]	#divided by 3
	protein = ''
	for n in range(len(seq[i])//3):
		protein += pt[seq[i][3*n:3*n+3]]
	sys.stdout.write('{}\n{}\n'.format(i,protein))
