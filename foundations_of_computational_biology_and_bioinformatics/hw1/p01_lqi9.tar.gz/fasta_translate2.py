#!/usr/bin/env python
#Question1:
import sys
b = sys.stdin			#input the file
c = []
dic = {}
des = b.readline().strip().rstrip('\n')    #first line & get the descriptor
line = b.readline()              #second line: sequence 
while line != "":
	d = line.rstrip('\n')
	c.append(d)
	line = b.readline()
b.close()
c = ''.join(c)                   #delete the ','
dic[des]=c
#Question2: use the code before to get the reading frame as the translation frame
mRNA = dic[des]	 #get the mRNA	sequence
codon = open("codon_table.txt",'r')
pt = {}				#create protain dictionary
line = codon.readline()
while line != "":
	a = line.rstrip().split('\t')
	pt[a[0]]=a[1]
	
	line = codon.readline()
codon.close()
protein = ''
for n in range(0,len(mRNA),3)[:-1]:
	protein += pt[mRNA[n:n+3]]
sys.stdout.write('{}\n{}\n'.format(des,protein))
